
import pandas
import requests
import json


def handler(event, context):
    
    print("The event tha I received was:")
    event_pretty = json.dumps(event, indent=4)
    print(event_pretty)


    return {
        "name": "testingLambdaPandasDependencies",
        "eventComplete": event
    }
 
