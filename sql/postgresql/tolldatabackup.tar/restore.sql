--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.4 (Debian 14.4-1+b1)
-- Dumped by pg_dump version 14.4 (Debian 14.4-1+b1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE tolldata;
--
-- Name: tolldata; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE tolldata WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE tolldata OWNER TO postgres;

\connect tolldata

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: toll; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA toll;


ALTER SCHEMA toll OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tolldata; Type: TABLE; Schema: toll; Owner: postgres
--

CREATE TABLE toll.tolldata (
    row_id integer NOT NULL,
    "timestamp" character varying(25),
    vehicle_id integer,
    vehicle_type character varying(10),
    payment_type integer,
    category_id character varying(10)
);


ALTER TABLE toll.tolldata OWNER TO postgres;

--
-- Data for Name: tolldata; Type: TABLE DATA; Schema: toll; Owner: postgres
--

COPY toll.tolldata (row_id, "timestamp", vehicle_id, vehicle_type, payment_type, category_id) FROM stdin;
\.
COPY toll.tolldata (row_id, "timestamp", vehicle_id, vehicle_type, payment_type, category_id) FROM '$$PATH$$/3323.dat';

--
-- Name: tolldata tolldata_pkey; Type: CONSTRAINT; Schema: toll; Owner: postgres
--

ALTER TABLE ONLY toll.tolldata
    ADD CONSTRAINT tolldata_pkey PRIMARY KEY (row_id);


--
-- Name: DATABASE tolldata; Type: ACL; Schema: -; Owner: postgres
--

GRANT CONNECT ON DATABASE tolldata TO backup;


--
-- Name: TABLE tolldata; Type: ACL; Schema: toll; Owner: postgres
--

GRANT SELECT ON TABLE toll.tolldata TO backup;


--
-- PostgreSQL database dump complete
--

